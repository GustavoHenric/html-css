#!/usr/bin/env node
require("musescore-downloader/dist/cli.js")
